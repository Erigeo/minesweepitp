#ifndef STRUCT_H_
#define STRUCT_H_

typedef struct {
  int Bomba;    // 0 para sem, 1 para com//
  int Quadrado; // 1 para aberto, 0 para fechado//
  int adjacentes;
} estrutura;

typedef enum { false, true } bool;






#endif