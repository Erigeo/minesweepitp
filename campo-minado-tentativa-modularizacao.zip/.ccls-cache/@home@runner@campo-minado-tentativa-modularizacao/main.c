#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "struct.h"
#include "funcoes.h"



int main(void) {
  jogar();
  return 0;
}
