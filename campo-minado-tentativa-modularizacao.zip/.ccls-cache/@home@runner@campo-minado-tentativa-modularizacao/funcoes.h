#ifndef FUNCOES_H
#define FUNCOES_H


void read_line(char linha[], int tam, FILE *f);
void inicializando_Campo();
void BOMBA_RANDOM();
void implementacao(int linha, int coluna);
void limparTela();
int verificador_valido(int linha, int coluna);
int Contador_minas_proximas(int linha, int coluna);
void preencher_dados_bombas_adjacentes();
void criacao_e_modificacao_board();
void revelar_bombas_final();
void verifica_vitoria(int *c);
int verifica_derrota(int linha, int coluna, int *c);
void recursao(int linha, int coluna);
int contador_quadrados_abertos_adjacentes(int linha, int coluna);
int contador_valores_adjacentes_abertos(int linha, int coluna);
void funcao_ajuda();
void modo_autonomo(int *x, int *y);
bool reiniciar();
void jogar();


#endif