#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "struct.h"
#include "funcoes.h"

void read_line(char linha[], int tam, FILE *f) {
  fgets(linha, tam, f);
  while (linha[0] == '\n')
    fgets(linha, tam, f);
  if (linha[strlen(linha) - 1] == '\n')
    linha[strlen(linha) - 1] = '\0';
}



estrutura campo[10][20];
int a = 10, b = 20, i, j;

void inicializando_Campo() {
  for (i = 0; i < a; i++) {
    for (j = 0; j < b; j++) {
      campo[i][j].Bomba = 0;
      campo[i][j].Quadrado = 0;
      campo[i][j].adjacentes = 0;
    }
  }
}


void BOMBA_RANDOM() {
  int minas = 40;
  srand((unsigned)time(NULL));
  do {
    i = rand() % 10;
    j = rand() % 20;
    if (campo[i][j].Bomba == 0) {
      campo[i][j].Bomba = 1;
      minas--;
    } /* Código que causa mais de 40 bombas
else {
      //minas++;
    } */
  } while (minas > 0);
}

void implementacao(int linha, int coluna) {
  int minas = 1;
  if (campo[linha][coluna].Bomba == 1) {
    do {
      i = rand() % 10;
      j = rand() % 20;
      if (campo[i][j].Bomba == 0) {
        campo[i][j].Bomba = 1;
        minas--;
      }
    } while (minas > 0);
    campo[linha][coluna].Bomba = 0;
  }
}

void limparTela(){ 
  system("clear"); 
  }

int verificador_valido(int linha, int coluna) {
  if (linha >= 0 && linha < a && coluna >= 0 && coluna < b) {
    return 1;
  } else {
    return 0;
  }
}

int Contador_minas_proximas(int linha, int coluna) {
  int minas = 0;
  if (campo[linha - 1][coluna - 1].Bomba == 1 &&
      verificador_valido(linha - 1, coluna - 1) == 1) {
    minas++;
  }
  if (campo[linha - 1][coluna].Bomba == 1 &&
      verificador_valido(linha - 1, coluna) == 1) {
    minas++;
  }
  if (campo[linha - 1][coluna + 1].Bomba == 1 &&
      verificador_valido(linha - 1, coluna + 1) == 1) {
    minas++;
  }
  if (campo[linha][coluna - 1].Bomba == 1 &&
      verificador_valido(linha, coluna - 1) == 1) {
    minas++;
  }
  if (campo[linha][coluna + 1].Bomba == 1 &&
      verificador_valido(linha, coluna + 1) == 1) {
    minas++;
  }
  if (campo[linha + 1][coluna - 1].Bomba == 1 &&
      verificador_valido(linha + 1, coluna - 1) == 1) {
    minas++;
  }
  if (campo[linha + 1][coluna].Bomba == 1 &&
      verificador_valido(linha + 1, coluna) == 1) {
    minas++;
  }
  if (campo[linha + 1][coluna + 1].Bomba == 1 &&
      verificador_valido(linha + 1, coluna + 1) == 1) {
    minas++;
  }

  return minas;
}

void preencher_dados_bombas_adjacentes() {
  for (i = 0; i < 10; i++) {
    for (j = 0; j < 20; j++) {
      campo[i][j].adjacentes = Contador_minas_proximas(i, j);
    }
  }
}

void criacao_e_modificacao_board() {
  for (i = 0; i < b; i++) {
    if (i == 0) {
      printf("   ");
    }
    if (i <= 10) {
      printf(" %d ", i);
    } else {
      printf("%d ", i);
    }
  }
  printf("\n");

  for (i = 0; i < a; i++) {
    if (i < 10) {
      printf(" %d ", i);
    } else {
      printf("%d", i + 1);
    }

    for (j = 0; j < b; j++) {
      if (campo[i][j].Quadrado == 1) {
        if (campo[i][j].Bomba == 1) {
          printf(" * ");
        } else {
          printf(" %d ", campo[i][j].adjacentes);
        }
      } else {
        printf(" # ");
      }
    }
    printf("\n");
  }
}

void revelar_bombas_final() {
  for (i = 0; i < a; i++) {
    for (j = 0; j < b; j++) {
      if (campo[i][j].Bomba == 1) {
        campo[i][j].Quadrado = 1;
      }
    }
  }
}

void verifica_vitoria(int *c) {
  *c = 0;
  int vic = 0;
  for (i = 0; i < a; i++) {
    for (j = 0; j < b; j++) {
      if (campo[i][j].Quadrado == 1 && campo[i][j].Bomba == 0) {
        vic++;
      }
    }
  }
  if (vic == 160) {
    revelar_bombas_final();
    printf("\nV I C T O R Y nhami nhami :9 \n");
    (*c)++;
  }
}


int verifica_derrota(int linha, int coluna, int *c) {
  if (campo[linha][coluna].Bomba == 1) {
    printf("\n \nBOOOOOM!!PLAAAA PLUUUTFUTUUT PERDEU! x( \n \n");
    printf("\nA coordenada L: %d C: %d era uma bomba!\n", linha, coluna);
    revelar_bombas_final();
    (*c) += 2;
    return 1;
  }
  return 0;
}


void recursao(int linha, int coluna) {
  campo[linha][coluna].adjacentes = Contador_minas_proximas(linha, coluna);
  if (campo[linha][coluna].Quadrado == 0) {
    if (campo[linha][coluna].adjacentes == 0) {
      campo[linha][coluna].Quadrado = 1;
      if (verificador_valido(linha - 1, coluna - 1) == 1) {
        recursao(linha - 1, coluna - 1);
      }

      if (verificador_valido(linha - 1, coluna) == 1) {
        recursao(linha - 1, coluna);
      }

      if (verificador_valido(linha - 1, coluna + 1) == 1) {
        recursao(linha - 1, coluna + 1);
      }

      if (verificador_valido(linha, coluna - 1) == 1) {
        recursao(linha, coluna - 1);
      }

      if (verificador_valido(linha, coluna + 1) == 1) {
        recursao(linha, coluna + 1);
      }

      if (verificador_valido(linha + 1, coluna - 1) == 1) {
        recursao(linha + 1, coluna - 1);
      }
      if (verificador_valido(linha + 1, coluna) == 1) {
        recursao(linha + 1, coluna);
      }
      if (verificador_valido(linha + 1, coluna + 1) == 1) {
        recursao(linha + 1, coluna + 1);
      }
    } else {
      campo[linha][coluna].Quadrado = 1;
    }
  }
}

int contador_quadrados_abertos_adjacentes(int linha, int coluna) {
  int adjacentes = 0;
  if (campo[linha - 1][coluna - 1].Quadrado == 1 &&
      verificador_valido(linha - 1, coluna - 1) == 1) {
    adjacentes++;
  }
  if (campo[linha - 1][coluna].Quadrado == 1 &&
      verificador_valido(linha - 1, coluna) == 1) {
    adjacentes++;
  }
  if (campo[linha - 1][coluna + 1].Quadrado == 1 &&
      verificador_valido(linha - 1, coluna + 1) == 1) {
    adjacentes++;
  }
  if (campo[linha][coluna - 1].Quadrado == 1 &&
      verificador_valido(linha, coluna - 1) == 1) {
    adjacentes++;
  }
  if (campo[linha][coluna + 1].Quadrado == 1 &&
      verificador_valido(linha, coluna + 1) == 1) {
    adjacentes++;
  }
  if (campo[linha + 1][coluna - 1].Quadrado == 1 &&
      verificador_valido(linha + 1, coluna - 1) == 1) {
    adjacentes++;
  }
  if (campo[linha + 1][coluna].Quadrado == 1 &&
      verificador_valido(linha + 1, coluna) == 1) {
    adjacentes++;
  }
  if (campo[linha + 1][coluna + 1].Quadrado == 1 &&
      verificador_valido(linha + 1, coluna + 1) == 1) {
    adjacentes++;
  }
  return adjacentes;
}

int contador_valores_adjacentes_abertos(int linha, int coluna) {
  int adjacentes = 0;
  if (campo[linha - 1][coluna - 1].Quadrado == 1 &&
      verificador_valido(linha - 1, coluna - 1) == 1) {
    adjacentes += campo[linha - 1][coluna - 1].adjacentes;
  }
  if (campo[linha - 1][coluna].Quadrado == 1 &&
      verificador_valido(linha - 1, coluna) == 1) {
    adjacentes += campo[linha - 1][coluna].adjacentes;
  }
  if (campo[linha - 1][coluna + 1].Quadrado == 1 &&
      verificador_valido(linha - 1, coluna + 1) == 1) {
    adjacentes += campo[linha - 1][coluna + 1].adjacentes;
  }
  if (campo[linha][coluna - 1].Quadrado == 1 &&
      verificador_valido(linha, coluna - 1) == 1) {
    adjacentes += campo[linha][coluna - 1].adjacentes;
  }
  if (campo[linha][coluna + 1].Quadrado == 1 &&
      verificador_valido(linha, coluna + 1) == 1) {
    adjacentes += campo[linha][coluna + 1].adjacentes;
  }
  if (campo[linha + 1][coluna - 1].Quadrado == 1 &&
      verificador_valido(linha + 1, coluna - 1) == 1) {
    adjacentes += campo[linha + 1][coluna - 1].adjacentes;
  }
  if (campo[linha + 1][coluna].Quadrado == 1 &&
      verificador_valido(linha + 1, coluna) == 1) {
    adjacentes += campo[linha + 1][coluna].adjacentes;
  }
  if (campo[linha + 1][coluna + 1].Quadrado == 1 &&
      verificador_valido(linha + 1, coluna + 1) == 1) {
    adjacentes += campo[linha + 1][coluna + 1].adjacentes;
  }
  return adjacentes;
}

void funcao_ajuda() {
  int contador, menor_numero = 60;
  int valor = 0;
  int matriz[10][20];
  for (i = 0; i < a; i++) {
    for (j = 0; j < b; j++) {
      contador = contador_quadrados_abertos_adjacentes(i, j);
      if (campo[i][j].Quadrado == 0 && contador > 0) {
        matriz[i][j] = contador_valores_adjacentes_abertos(i, j);
        if (matriz[i][j] < menor_numero && matriz[i][j] != 0) {
          menor_numero = matriz[i][j];
        }
      }
    }
  }
  srand((unsigned)time(NULL));
  bool teste = false;
  do {
    i = rand() % 10;
    j = rand() % 20;
    contador = contador_quadrados_abertos_adjacentes(i, j);
    if (campo[i][j].Quadrado == 0 && contador > 0) {
      if (matriz[i][j] == menor_numero) {
        teste = true;
        printf("Tente as coordenadas L: %d e C: %d", i, j);
      }
    }
  } while (teste == false);
}

void modo_autonomo(int *x, int *y) {
  int contador, menor_numero = 60;
  int valor = 0;
  int matriz[10][20];
  for (i = 0; i < a; i++) {
    for (j = 0; j < b; j++) {
      contador = contador_quadrados_abertos_adjacentes(i, j);
      if (campo[i][j].Quadrado == 0 && contador > 0) {
        matriz[i][j] = contador_valores_adjacentes_abertos(i, j);
        if (matriz[i][j] < menor_numero && matriz[i][j] != 0) {
          menor_numero = matriz[i][j];
        }
      }
    }
  }
  srand((unsigned)time(NULL));
  bool teste = false;
  do {
    *x = rand() % 10;
    *y = rand() % 20;
    contador = contador_quadrados_abertos_adjacentes(*x, *y);
    if (campo[*x][*y].Quadrado == 0 && contador > 0) {
      if (matriz[*x][*y] == menor_numero) {
        teste = true;
        printf("\n Usei as coordenadas L: %d C: %d \n", *x, *y);
        recursao(*x, *y);
      }
    }
  } while (teste == false);
}


bool reiniciar() {
  char *string = malloc(sizeof(char));
  printf("\nTem certeza de que deseja reiniciar o jogo?\n -> Digite \"SIM\" caso "
         "queira\n -> Digite \"NAO\" para voltar\n");
  int tam_max_opcoes = 3;

  string = realloc(string, (tam_max_opcoes + 1) * sizeof(char));

  read_line(string, tam_max_opcoes + 1, stdin);

  if (strcmp(string, "SIM") == 0) {
    limparTela();
    inicializando_Campo();
    return true;
  }
  return false;
} 

void jogar() {
  double time_spent = 0.0;
  time_t begin_t = 0.0;
  time_t end_t = 0.0;
  estrutura campo[10][20];
  int comando, i, j, linha, coluna, contador, n = 0;
  int c = 0, x, y, contador_de_jogadas = 0;
  printf("----------------------CAMPO MINADO V1.0------------------------\n");
  do {
    begin_t = time(NULL);
    contador_de_jogadas = contador_de_jogadas + 1;
  } while (contador_de_jogadas == 0);
  inicializando_Campo();
  BOMBA_RANDOM();
  criacao_e_modificacao_board();
  do {
    printf("\n ");
    printf("lista de comandos:\n 1-Revelar cédula \n 2-Tempo de jogo atual \n "
           "3-Ajuda\n 4-Modo Autônomo \n 5-Reiniciar \n");
    scanf("%d", &comando);
    switch (comando) {
    case 1:
      contador_de_jogadas = contador_de_jogadas + 1;
      printf("Entre com as coordenadas (x, y) de sua jogada:\n ");
      scanf("%d %d", &linha, &coluna);
      if (verificador_valido(linha, coluna) == 1) {
        if (n == 0) {
          implementacao(linha, coluna);
          recursao(linha, coluna);
          if (verifica_derrota(linha, coluna, &c) == 1) {
            criacao_e_modificacao_board();
            n += 1;
            break;
          }
        }
        recursao(linha, coluna);
        if (verifica_derrota(linha, coluna, &c) == 1) {
          criacao_e_modificacao_board();
          break;
        }
        criacao_e_modificacao_board();
        verifica_vitoria(&c);
      } else {
        printf("\nInsira coordenadas válidas!\n");
      }
      n = 1;
      break;
    case 2:
      end_t = time(NULL);
      time_spent = difftime(end_t, begin_t);
      printf("Tempo total de jogo: %.2lf\n", time_spent);
      printf("Número de jogadas: %d\n", contador_de_jogadas);
      break;
    case 3:
      if (n == 0) {
        i = rand() % 10;
        j = rand() % 20;
        printf(" É a primeira jogada, não tenho dados :( \n Pode tentar as "
               "coordenadas aleatórias L: %d e C: %d",
               i, j);
        break;
      }
      funcao_ajuda();

      break;
    case 4:
      printf("\nBem-vindo ao modo autônomo!\n");
      do {
        if (n == 0) {
          n = 1;
          i = rand() % 10;
          j = rand() % 20;
          implementacao(i, j);
          recursao(i, j);
          if (verifica_derrota(i, j, &c) == 1) {
            criacao_e_modificacao_board();
            break;
          }
          printf("\nUsei as coordenadas L: %d C: %d\n", i, j);
          criacao_e_modificacao_board();
        }
        modo_autonomo(&x, &y);
        if (verifica_derrota(x, y, &c) == 1) {
          criacao_e_modificacao_board();
          break;
        }
        criacao_e_modificacao_board();
        verifica_vitoria(&c);
        contador_de_jogadas = contador_de_jogadas + 1;
      } while (c == 0);
      break;
    case 5: {
      bool aux = reiniciar();
      if (aux == true) {
        jogar();
      }
      break;
      } 
    default:
      printf("Comando inválido!");
      break;
    }
  } while (c == 0);
  end_t = time(NULL);
  time_spent = difftime(end_t, begin_t);
  printf(
      "O número de jogadas anteriores foram : %d \nTempo total de jogo em segundos: %.2lf",
      contador_de_jogadas, time_spent);
  bool aux = reiniciar();
      if (aux == true) {
        jogar();
      }
}

