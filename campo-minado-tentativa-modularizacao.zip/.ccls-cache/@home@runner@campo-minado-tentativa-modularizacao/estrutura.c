
typedef struct {
  int Bomba;    // 0 para sem, 1 para com//
  int Quadrado; // 1 para aberto, 0 para fechado//
  int adjacentes;
} estrutura;



estrutura campo[10][20];
int a = 10, b = 20, i, j;


void inicializando_Campo() {
  for (i = 0; i < a; i++) {
    for (j = 0; j < b; j++) {
      campo[i][j].Bomba = 0;
      campo[i][j].Quadrado = 0;
      campo[i][j].adjacentes = 0;
    }
  }
}



int verificador_valido(int linha, int coluna) {
  if (linha >= 0 && linha < a && coluna >= 0 && coluna < b) {
    return 1;
  } else {
    return 0;
  }
}

void criacao_e_modificacao_board() {
  for (i = 0; i < b; i++) {
    if (i == 0) {
      printf("   ");
    }
    if (i <= 10) {
      printf(" %d ", i);
    } else {
      printf("%d ", i);
    }
  }
  printf("\n");

  for (i = 0; i < a; i++) {
    if (i < 10) {
      printf(" %d ", i);
    } else {
      printf("%d", i + 1);
    }

    for (j = 0; j < b; j++) {
      if (campo[i][j].Quadrado == 1) {
        if (campo[i][j].Bomba == 1) {
          printf(" * ");
        } else {
          printf(" %d ", campo[i][j].adjacentes);
        }
      } else {
        printf(" # ");
      }
    }
    printf("\n");
  }
}