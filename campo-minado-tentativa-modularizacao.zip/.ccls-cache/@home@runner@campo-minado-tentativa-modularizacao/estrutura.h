#ifndef ESTRUTURA_H
#define ESTRUTURA_H


void inicializando_Campo();
void BOMBA_RANDOM();
int verificador_valido(int linha, int coluna);
void criacao_e_modificacao_board();











#endif